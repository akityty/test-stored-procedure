create
    definer = root@localhost procedure sp_insert_product(IN active int, IN createDate datetime,
                                                         IN description varchar(255), IN image varchar(255),
                                                         IN name varchar(255), IN price double, IN quantity double)
BEGIN
INSERT INTO products (
active
, createDate
, description
, image
, name
, price
, quantity)
   VALUES (active
   , createDate
   , description
   , image
   , name
   , price
   , quantity);
END;

